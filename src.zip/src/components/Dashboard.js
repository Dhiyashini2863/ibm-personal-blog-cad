import React, { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import './Dashboard.css';

const Dashboard = () => {
    const [employee, setEmployee] = useState(null);
    const [leaveDays, setLeaveDays] = useState(0);
    const { empId } = useAuth();
    const currentMonth = new Date().getMonth();
    const currentYear = new Date().getFullYear();
    const today = new Date();
    today.setHours(0, 0, 0, 0); // Set time to the start of the day for accurate comparison

    useEffect(() => {
        if (empId) {
            fetchEmployeeDetails();
            fetchTimesheets();
        } else {
            alert('Employee ID not found');
        }
    }, [empId]);

    const fetchEmployeeDetails = async () => {
        try {
            const response = await fetch(`http://127.0.0.1:8000/api/timesheet/?emp=${empId}`);
            if (response.ok) {
                const data = await response.json();
                setEmployee(data);
            } else {
                alert('Error fetching employee details');
            }
        } catch (error) {
            alert('Error fetching employee details');
        }
    };

    const fetchTimesheets = async () => {
        try {
            const response = await fetch(`http://127.0.0.1:8000/api/timesheet/?emp=${empId}&month=${currentMonth + 1}&year=${currentYear}`);
            if (response.ok) {
                const data = await response.json();
                calculateLeaveDays(data);
            } else {
                alert('Error fetching timesheets');
            }
        } catch (error) {
            alert('Error fetching timesheets');
        }
    };

    const calculateLeaveDays = (timesheets) => {
        const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();
        const updatedDates = timesheets.map(ts => new Date(ts.date).getDate());
        
        // Calculate leave days excluding today
        const leaveDaysCount = Array.from({ length: daysInMonth }, (_, i) => i + 1)
            .filter(day => {
                const date = new Date(currentYear, currentMonth, day);
                return date < today && !updatedDates.includes(day);
            }).length;
        
        setLeaveDays(leaveDaysCount);
    };

    return (
        <div className="dashboard-container">
            <div className="dashboard-content">
                <h1>Welcome, {employee ? employee.emp_name : 'Loading...'}</h1>
                <p>Employee ID: {empId}</p>
                <p>Your Total Leave days of this Month: {leaveDays}</p>
            </div>
        </div>
    );
};

export default Dashboard;
