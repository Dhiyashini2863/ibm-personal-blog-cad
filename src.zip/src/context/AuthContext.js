// src/context/AuthContext.js
import { createContext, useContext, useState } from 'react';

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
    const [empId, setEmpId] = useState(null);

    const login = (id) => setEmpId(id);
    const logout = () => setEmpId(null);

    return (
        <AuthContext.Provider value={{ empId, login, logout }}>
            {children}
        </AuthContext.Provider>
    );
};

export const useAuth = () => useContext(AuthContext);
